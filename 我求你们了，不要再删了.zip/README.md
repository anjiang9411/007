
  # 我求你们了，不要再删了

  This is a code bundle for 我求你们了，不要再删了. The original project is available at https://www.figma.com/design/6xerLK7fJKXISH2BAFiqfp/%E6%88%91%E6%B1%82%E4%BD%A0%E4%BB%AC%E4%BA%86%EF%BC%8C%E4%B8%8D%E8%A6%81%E5%86%8D%E5%88%A0%E4%BA%86.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  